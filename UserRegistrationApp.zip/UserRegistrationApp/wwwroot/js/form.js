﻿$(document).ready(function () {

    $.get("/User/GetStates", function (data) {
        $.each(data, function (i, item) {
            $('#StateId').append(`<option value="${item.id}">${item.name}</option>`);
        });
    });

    $('#StateId').change(function () {
        var stateId = $(this).val();
        $('#CityId').empty().append('<option>Select City</option>');
        $.get("/User/GetCities/" + stateId, function (data) {
            $.each(data, function (i, item) {
                $('#CityId').append(`<option value="${item.id}">${item.name}</option>`);
            });
        });
    });

    //validate form
    $('#registrationForm').submit(function (e) {
        const contact = $('#ContactNo').val();
        const dob = $('#DateOfBirth').val();
        const regex = /^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/(19|20)\d\d$/;


        if (!contact) {
            alert('Contact No. is required.');
            e.preventDefault();
            return;
        }

        if (!regex.test(dob)) {
            alert("Date must be in dd/mm/yyyy format");
            $('#DateOfBirth').focus();
            e.preventDefault();
            return;
        }

        if (!$('#termsCheckbox').is(':checked')) {
            alert('You must agree to terms.');
            e.preventDefault();
        }
    });

    $('#DateOfBirth').attr("placeholder", "dd/mm/yyyy");

    //Dynamic dob format checking
    $('#DateOfBirth').on('blur', function () {
        var dob = $(this).val();
        var regex = /^(0[1-9]|[12][0-9]|3[01])[\/](0[1-9]|1[012])[\/](19|20)\d\d$/;
        if (dob && !regex.test(dob)) {
            alert("Date must be in dd/mm/yyyy format");
            $(this).focus();
        }
    });
});
