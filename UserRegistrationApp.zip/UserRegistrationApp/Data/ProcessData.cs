﻿using Microsoft.EntityFrameworkCore;
using UserRegistrationApp.Models;

namespace UserRegistrationApp.Data
{
    public class ProcessData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new ApplicationDbContext(
                serviceProvider.GetRequiredService<DbContextOptions<ApplicationDbContext>>()))
            {
                if (!context.States.Any())      //Check if exist else instert
                {
                    var delhi = new State { Name = "Delhi" };
                    var up = new State { Name = "Uttar Pradesh" };

                    context.States.AddRange(delhi, up);
                    context.SaveChanges();

                    var cities = new List<City>
                    {
                        new City { Name = "New Delhi", StateId = delhi.Id },
                        new City { Name = "Delhi", StateId = delhi.Id },
                        new City { Name = "Noida", StateId = up.Id },
                        new City { Name = "Lucknow", StateId = up.Id },
                    };

                    context.Cities.AddRange(cities);
                    context.SaveChanges();
                }

                //if (context.States.Any())
                //{
                //    
                //}
            }
        }
    }
}
