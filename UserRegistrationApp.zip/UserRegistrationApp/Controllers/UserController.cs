﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using UserRegistrationApp.Data;
using UserRegistrationApp.Models;

namespace UserRegistrationApp.Controllers
{
    public class UserController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _env;

        public UserController(ApplicationDbContext context, IWebHostEnvironment env)
        {
            _context = context;
            _env = env;
        }

        public IActionResult Register() => View();

        [HttpPost]
        public async Task<IActionResult> Register(User model, IFormFile Photo)
        {
            if (Photo != null)
            {
                var ext = Path.GetExtension(Photo.FileName);

                if (ext != ".jpg" && ext != ".png")
                    ModelState.AddModelError("Photo", "Only .jpg and .png allowed");

                var path = Path.Combine(_env.WebRootPath, "uploads", Photo.FileName);
                using (var stream = new FileStream(path, FileMode.Create))
                {
                    await Photo.CopyToAsync(stream);
                }
                model.PhotoPath = "/uploads/" + Photo.FileName;
            }

            if (!ModelState.IsValid)
                return View(model);

            _context.Users.Add(model);
            await _context.SaveChangesAsync();
            return RedirectToAction("List");
        }

        public async Task<IActionResult> List(string nameFilter = "", int page = 1, int pageSize = 5)
        {
            var usersQuery = _context.Users
        .Include(u => u.State)
        .Include(u => u.City)
        .AsQueryable();

            if (!string.IsNullOrWhiteSpace(nameFilter))
            {
                usersQuery = usersQuery.Where(u => u.Name.ToLower().Contains(nameFilter.ToLower()));
            }

            var totalUsers = await usersQuery.CountAsync();
            var users = await usersQuery
                .OrderBy(u => u.Name)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            ViewBag.CurrentPage = page;
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalUsers / pageSize);
            ViewBag.NameFilter = nameFilter;

            return View(users);
        }

        [HttpGet]
        public JsonResult GetStates()
        {
            var states = _context.States.ToList();
            return Json(states);
        }

        [HttpGet]
        public JsonResult GetCities(int id)
        {
            var cities = _context.Cities.Where(c => c.StateId == id).ToList();
            return Json(cities);
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}