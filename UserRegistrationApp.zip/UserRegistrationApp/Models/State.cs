﻿using System.ComponentModel.DataAnnotations;

namespace UserRegistrationApp.Models
{
    public class State
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        public virtual ICollection<City> Cities { get; set; }
    }
}